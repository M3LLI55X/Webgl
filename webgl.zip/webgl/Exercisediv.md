# WORKSHHET 1
## The easist excise, Yao created a canvas and a WebGL context, used the shader programs, setup the needed buffers for drawing, Jiaqi drew the circle and square.
# WORKSHEET 2
## From points to trangle and circle, Yao worked on drawing points and triangle, Jiaqi worked on drawing circle, and we woked together for the ws2part4.
# WORKSHEET 3
## We drew the picture of isometric view, and classical perspective views.
# WORKSHEET 4
## We drew the sphere. Then we drew a diffuse sphere lit by a light. And Implement the full Phong reflection model. Used Phong shading
# WORKSHEET 5
## Jiaqi placed the WebGL application on DTU Student Homepage
# WORKSHEET 6
## Yao drew the rectangles, Jiaqi map the earth texture onto the sphere.
# WORKSHEET 7
## We discussed the problem of using environment mapping to render a curved reflector and how to use cube maps and the reflection function. 
# WORKSHEET 8
## Yao replaced the checkerboard texture in W6 by the texture image in xamp23.png, and draw the original graph, Jiaqi add the projection shadows, and we make the shadow more grey, rather black.
# WORKSHEET 9
## Jiaqi drew the Scene and projection shadows for reference, Yao drew the Shadow mapping. And based on part2, we completed the project.
# WORKSHEET 10
## We saw the sample in DTU learn: https://courses.compute.dtu.dk/02560/lectures/week02/trackball.html, and drew a cube like this.